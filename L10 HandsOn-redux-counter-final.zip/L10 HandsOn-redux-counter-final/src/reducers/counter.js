const initialState = {
  count: 0,
  numberInputted: 0,
  timesClicked: 0
};

function counterReducer(state = initialState, action) {
  switch (action.type) {
    case 'INCREMENT':
      return {
        ...state,
        count: state.count + 1,
        timesClicked: state.timesClicked + 1
      };
    case 'DECREMENT':
      return {
        ...state,
        count: state.count - 1,
        timesClicked: state.timesClicked + 1
       };
    case "INPUT_NUMBER_CHANGE":
      return {
        ...state,
        numberInputted: action.number
//      timesClicked: (state.count = 0) - try this for a new reset All button

      };
    case "INPUT_NUMBER":
        return {
          ...state,
          count: parseInt(state.numberInputted),
          numberInputted: null, //consider changing
          timesClicked: 0
        };
    // case 'RESET ALL': - move this the only button or a new button
    //   return {
    //     ...state,
    //     count: (state.count = 0)
    //     timesClicked: (state.count = 0) - try this for a new reset All button
    //   };
    default:
      return state;
  }
}

export default counterReducer;